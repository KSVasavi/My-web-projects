import sqlite3

# Connect to the database
conn = sqlite3.connect('database.db')
c = conn.cursor()

# Check if the 'expenses' table exists
c.execute("PRAGMA table_info(expenses)")
columns = [row[1] for row in c.fetchall()]

# Add 'user_id' column if it does not exist
if 'user_id' not in columns:
    c.execute('''
        ALTER TABLE expenses
        ADD COLUMN user_id INTEGER NOT NULL;
    ''')
    conn.commit()

# Close the connection
conn.close()

print("Database schema updated.")
