import sqlite3

def update_database():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    # Add user_id column if it doesn't exist
    c.execute("PRAGMA table_info(expenses);")
    columns = [row[1] for row in c.fetchall()]
    if 'user_id' not in columns:
        c.execute("ALTER TABLE expenses ADD COLUMN user_id INTEGER;")
        print("Column 'user_id' added to 'expenses' table.")
    else:
        print("Column 'user_id' already exists in 'expenses' table.")
    
    conn.commit()
    conn.close()

if __name__ == '__main__':
    update_database()
